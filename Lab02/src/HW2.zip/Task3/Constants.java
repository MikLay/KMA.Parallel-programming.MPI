package Task3;

public interface Constants {
  int PHILOSOPHERS_AMOUNT = 5;
  int DINNER_TIME = 1000;
  int THINKING_TIME = 1;
  String[] names = {
    "Платон[0]",
    "Конфуцій[1]",
    "Спіноза[2]",
    "Декарт[3]",
    "Сократ[4]",
  };
}
