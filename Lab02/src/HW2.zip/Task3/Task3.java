package Task3;

import Task3.monitor.MonitorStart;
import Task3.naive.NaiveStart;

public class Task3 {

  public static void main(String[] args) {
    NaiveStart naiveStart = new NaiveStart();
    naiveStart.starter();
    /* MonitorStart monitorStart = new MonitorStart();
    monitorStart.starter();*/
  }
}
